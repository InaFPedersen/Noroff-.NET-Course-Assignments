# Kata 
This folder contains Kata number 14.
## Name
10001st Prime

## Description
10001st Prime
By listing the first six prime numbers: 2, 3, 5, 7, 11, and 13, we can see that the 6th prime is 13.

What is the 10 001st prime number?

https://projecteuler.net/problem=7

## Authors and acknowledgment
Written by Ina F. Pedersen

## Project status
Completed