# Kata 
This folder contains Kata number 24.
## Name
Convert Minutes into Seconds

## Description
Convert Minutes into Seconds
Write a function that takes an integer minutes and converts it to seconds.

Examples
convert(5) ➞ 300

convert(3) ➞ 180

convert(2) ➞ 120
Notes
Don't forget to return the result.
If you get stuck on a challenge, find help in the Resources tab.
If you're really stuck, unlock solutions in the Solutions tab.


Found at: https://edabit.com/challenge/bizjGL4wyd8PwR4Ke

## Authors and acknowledgment
Written by Ina F. Pedersen

## Project status
Completed