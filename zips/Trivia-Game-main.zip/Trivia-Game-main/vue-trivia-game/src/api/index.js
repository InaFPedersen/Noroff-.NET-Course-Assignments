export const BASE_URL = "https://trivia-api-ifp.herokuapp.com/"
export const API_KEY = "l2lu366y4bifdn32ruyntvfwset"